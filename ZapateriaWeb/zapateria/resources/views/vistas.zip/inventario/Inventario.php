<!DOCTYPE html>
<html>

<head>
    <title>Inicio de sesión</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/StyleCatalogo.css">
</head>
<header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light rounded mb-3 pb-3">
        <a class="navbar-brand" href="#">
            <img src="../Images/icono.png" width="50px" height="50px" alt="Logo de la Zapatería">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="Inventario.html">Inicio</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="Registrar.html">Agregar productos</a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0">
                <input class="form-control mr-sm-2" type="search" placeholder="Buscar" aria-label="Buscar">
                <button class="btn btn-light my-2 my-sm-0" type="submit">
                    <img src="../Images/lupa.png" width="26px" height="26px" alt="Lupa">
                </button>
            </form>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <button class="btn btn-circle btn-light ml-3">
                        <img src="../Images/perfil.png" width="26px" height="26px" alt="Perfil">
                        Perfil
                    </button>
                </li>
            </ul>
        </div>
    </nav>
</header>
</header>

<body>
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Precio</th>
                <th>Imagen</th>
                <th>Talla</th>
                <th>Material</th>
                <th>Estilo</th>
                <th>Color</th>
                <th>Cantidad</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody id="tabla-productos">
        </tbody>
    </table>
</body>
<script src="../../js/Inventario.js"></script>

</html>