<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Document</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<body>
  <div class="container">
    <h2>Editar</h2>
    <form>
      <div class="form-group">
        <label for="idInput">ID:</label>
        <input type="text" class="form-control" id="idInput" required>
      </div>
      <div class="form-group">
        <label for="nombreInput">Nombre:</label>
        <input type="text" class="form-control" id="nombreInput" required>
      </div>
      <div class="form-group">
        <label for="precioInput">Precio:</label>
        <input type="number" class="form-control" id="precioInput" required>
      </div>
      <div class="form-group">
        <label for="imagenInput">Imagen:</label>
      </div>
      <div class="form-group">
        <label for="tallaInput">Talla:</label>
        <input type="text" class="form-control" id="tallaInput" required>
      </div>
      <div class="form-group">
        <label for="materialInput">Material:</label>
        <input type="text" class="form-control" id="materialInput" required>
      </div>
      <div class="form-group">
        <label for="estiloInput">Estilo:</label>
        <input type="text" class="form-control" id="estiloInput" required>
      </div>
      <div class="form-group">
        <label for="colorInput">Color:</label>
        <input type="text" class="form-control" id="colorInput" required>
      </div>
      <div class="form-group">
        <label for="cantidadInput">Cantidad:</label>
        <input type="number" class="form-control" id="cantidadInput" required>
      </div>
      <div class="form-group">
        <label for="imagenInput">Imagen:</label>
      </div>
      <button type="submit" href="Inventario.html" class="btn btn-primary mt-3">Guardar</button>
    </form>
  </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</html>
