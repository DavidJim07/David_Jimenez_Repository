<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="../../css/StyleCatalogo.css">
</head>
<header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light rounded mb-3 pb-3">
        <a class="navbar-brand" href="#">
            <img src="../Images/icono.png" width="50px" height="50px" alt="Logo de la Zapatería">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto custom-list">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Inicio</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="#">Caballero</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="#">Dama</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="#">Niños</a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0">
                <input class="form-control mr-sm-2" type="search" placeholder="Buscar" aria-label="Buscar">
                <button class="btn btn-light my-2 my-sm-0" type="submit">
                    <img src="../Images/lupa.png" width="26px" height="26px" alt="Lupa">
                </button>
            </form>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <button class="btn btn-circle btn-light ml-3">
                        <img src="../Images/perfil.png" width="26px" height="26px" alt="Perfil">
                        Perfil
                    </button>
                </li>
            </ul>
        </div>
    </nav>
</header>

<body>
    <div class="container">
        <div class="row">
            <main id="items" class="col-sm-8 row"></main>
            <aside class="col-sm-4 custom-carrito">
                <h2>Carrito</h2>
                <ul id="carrito" class="list-group"></ul>
                <hr>
                <p class="text-right">Total: &dollar;<span id="total"></span></p>
                <button id="boton-vaciar" class="btn btn-danger">Pagar</button>
            </aside>
        </div>
    </div>
</body>
<script src="../../js/Carrito.js"></script>

</html>