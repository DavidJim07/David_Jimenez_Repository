<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="{{ mix('css/app.css') }}" rel="stylesheet" type="text/css" />
    <title>Registro Tarjetas</title>
</head>
<body>
    <br>
    <div class="container-fluid" name='registro'>
        <div class="container-fluid">
            <div class="card">
                <div class="card-header text-center">
                    <h5>Tarjetas Registradas</h5>
                </div>
                <div class="card-body">

                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
                        <label class="form-check-label" for="flexRadioDefault1">Texto con el nombre de tarjeta</label>
                    </div>
                    
                    <br>
                    <button type='submit' id='guardar' class="btn btn-success">Aceptar</button>  
                    <br><hr>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">Agregar Nueva Tarjeta</label>
                    </div>
                    <div class="row">
                        <div class="col">
                            <h5 class="card-header text-center" >Tarjeta</h5>
                            <div class="row">
                                <div class="col">
                                    <div class="mb-3">
                                        <label class="form-label" >Nombre Tarjeta:</label>
                                        <input type='text' id='tarjeta' name='tarjeta' class="form-control"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" >Número de la Tajeta:</label>
                                        <input type='text' id='numeroTarjeta' name='numeroTarjeta' class="form-control" maxlength="3"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" >Fecha de Vencimiento:</label>
                                        <input type='date' id='vencimiento' name='vencimiento' class="form-control"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" >CCV:</label>
                                        <input type='number' id='ccv' name='ccv' class="form-control"/>
                                    </div>
                                </div>
                                <div class="col"></div>
                                <div class="col"></div>
                            </div>
                            <hr>
                            <button type='submit' id='guardar' class="btn btn-success">Registrar Tarjeta</button>  
                            <button type='reset' id='limpiar' class="btn btn-warning">Limpiar Cajas</button> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<script src="{{ mix('js/app.js') }}" type="text/javascript"></script>
</html>