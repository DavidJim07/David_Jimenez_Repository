<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="{{ mix('css/app.css') }}" rel="stylesheet" type="text/css" />
    <title>Registro Usuario</title>
</head>
<body>
    <br>
    <div class="container-fluid" name='registro'>
        <div class="container-fluid">
            <div class="card">
                <div class="card-header text-center">
                    Registro Usuario
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h5 class="h5 text-center">Datos Personales</h5>
                            <div class="mb-3">
                                <label class="form-label" >Nombre:</label>
                                <input type='text' id='nombre' name='nombre' class="form-control"/>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" >Apellido Paterno:</label>
                                <input type='text' id='paterno' name='paterno' class="form-control"/>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" >Apellido Materno:</label>
                                <input type='text' id='materno' name='materno' class="form-control"/>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" >Fecha de Nacimiento:</label>
                                <input type='date' id='nacimiento' name='nacimiento' class="form-control"/>
                            </div>
                        </div>
                        <div class="col">
                            <h5 class="h5 text-center">Domicilio</h5>
                            <div class="row">
                                <div class="col">
                                    <div class="mb-3">
                                        <label class="form-label" >Pais:</label>
                                        <input type='text' id='pais' name='pais' class="form-control"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" >Estado:</label>
                                        <input type='text' id='estado' name='estado' class="form-control"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" >Ciudad:</label>
                                        <input type='text' id='ciudad' name='ciudad' class="form-control"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" >Colonia:</label>
                                        <input type='text' id='colonia' name='colonia' class="form-control"/>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="mb-3">
                                        <label class="form-label" >Calle:</label>
                                        <input type='text' id='calle' name='calle' class="form-control"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" >Numero:</label>
                                        <input type='number' id='numero' name='numero' class="form-control"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" >EntreCalles:</label>
                                        <input type='text' id='entreCalles' name='entreCalles' class="form-control"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                <label class="form-check-label" for="flexCheckDefault">Agregar datos Bancarios</label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" >Nombre Tarjeta:</label>
                                <input type='text' id='tarjeta' name='tarjeta' class="form-control"/>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" >Número de la Tajeta:</label>
                                <input type='text' id='numeroTarjeta' name='numeroTarjeta' class="form-control" maxlength="3"/>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" >Fecha de Vencimiento:</label>
                                <input type='date' id='vencimiento' name='vencimiento' class="form-control"/>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" >CCV:</label>
                                <input type='number' id='ccv' name='ccv' class="form-control"/>
                            </div>
                        </div>
                        <div class="col"></div>
                        <div class="col"></div>
                    </div>
                    <hr>
                    <button type='submit' id='guardar' class="btn btn-success">Registrarse</button>  
                    <button type='reset' id='limpiar' class="btn btn-warning">Limpiar Cajas</button> 
                </div>
            </div>
        </div>
    </div>
</body>
<script src="{{ mix('js/app.js') }}" type="text/javascript"></script>
</html>