<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="{{ mix('css/app.css') }}" rel="stylesheet" type="text/css" />
    <title>Registro Domicilio</title>
</head>
<body>
    <br>
    <div class="container-fluid" name='registro'>
        <div class="container-fluid">
            <div class="card">
                <div class="card-header text-center">
                    <h5>Domicilios Registrados</h5>
                </div>
                <div class="card-body">

                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
                        <label class="form-check-label" for="flexRadioDefault1">Texto con el domicilio o domicilios</label>
                    </div>
                    
                    <br>
                    <button type='submit' id='guardar' class="btn btn-success">Aceptar</button>  
                    <br><hr>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">Agregar Nuevo Domicio</label>
                    </div>
                    <div class="row">
                        <div class="col">
                            <h5 class="card-header text-center" >Domicilio</h5>
                            <div class="row">
                                <div class="col">
                                    <div class="mb-3">
                                        <label class="form-label" >Pais:</label>
                                        <input type='text' id='pais' name='pais' class="form-control"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" >Estado:</label>
                                        <input type='text' id='estado' name='estado' class="form-control"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" >Ciudad:</label>
                                        <input type='text' id='ciudad' name='ciudad' class="form-control"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" >Colonia:</label>
                                        <input type='text' id='colonia' name='colonia' class="form-control"/>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="mb-3">
                                        <label class="form-label" >Calle:</label>
                                        <input type='text' id='calle' name='calle' class="form-control"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" >Numero:</label>
                                        <input type='number' id='numero' name='numero' class="form-control"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" >EntreCalles:</label>
                                        <input type='text' id='entreCalles' name='entreCalles' class="form-control"/>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <button type='submit' id='guardar' class="btn btn-success">Registrar Domicilio</button>  
                            <button type='reset' id='limpiar' class="btn btn-warning">Limpiar Cajas</button> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<script src="{{ mix('js/app.js') }}" type="text/javascript"></script>
</html>