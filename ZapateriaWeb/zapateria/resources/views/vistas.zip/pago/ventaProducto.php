<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="{{ mix('css/app.css') }}" rel="stylesheet" type="text/css" />
    <title>Venta Producto</title>
</head>
<body>
    <br>
    <div class="container-fluid">
        <div class="row">
            <div class="col-8">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header">
                            <h1 class="h1">Carrito</h1>
                            <a href="#">Deseleccionar todos los artículos </a>
                        </div>
                        <div class="card-body">
                            <div class="container-fluid">
                                <div class="row g-4" id="contenedorCarrito" name="contenedorCarrito">

                                    <div class="col">
                                        <div class="card" style="width: 18rem;">
                                            <div class="p-3">
                                                <img src="../../dm 150.jpg" class="card-img-top" alt="Aqui va la imagen del producto">
                                                <h5 class="card-title text-center">Producto</h5>
                                                <p class="card-text">Descripción del producto</p>
                                                <div class="row">
                                                    <div class="col">
                                                        <button class="btn btn-danger">Quitar</button>
                                                    </div>
                                                    <div class="col">
                                                        <h6 class="h6">Cantidad:</h6>
                                                    </div>
                                                    <div class="col">
                                                        <select class="form-select">
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="container-fluid" style="text-align: right;"><strong id="subtotal" name="subtotal">Subtotal: ("CantidadProductos"): CantidadAPagar</strong></div>
                    </div>
                </div>
            </div>
        
            <div  class="col">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-body">
                            <p class="card-text" id="tipoEnvio" name="tipoEnvio">Tu pedido es con envio gratis o mostrar el costo del envio</p>
                            <strong id="subtotal2" name="subtotal2">Subtotal: ("CantidadProductos"): CantidadAPagar</strong>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                <label class="form-check-label" for="flexCheckDefault">Es un regalo</label>
                            </div>
                            <hr>
                            <div class="d-grid gap-2">
                                <a href="procederPago.html" class="btn btn-warning text-center">Proceder a pagar</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</body>
<script src="{{ mix('js/app.js') }}" type="text/javascript"></script>
</html>

