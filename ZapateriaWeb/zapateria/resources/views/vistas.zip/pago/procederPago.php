<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="{{ mix('css/app.css') }}" rel="stylesheet" type="text/css" />
    <title>Proceder Pago</title>
</head>
<body>
    <br>
    <div class="alert alert-secondary text-center" role="alert">
        <h2 class="h2" id="titulo" name="titulo">Proceder a Pago(CantidadArtículos)</h2>
    </div>
    <div class="row">
        <div class="col-8">
            <div class="container-fluid">
                <table class="table table-striped">
                    <tr>
                        <th scope="row"><h2>1</h2></th>
                        <td colspan="-1"><h2>Dirección De Envió</h2></td>
                        <td><div id="nombrePersona" name="nombrePersona">Nombre de la Persona</div> 
                            <div id="calleYNumero" name="calleYNumero">Calle y numero</div> 
                            <div id="colonia" name="colonia">Colonia</div> 
                            <div id="ciudadYEstado" name="ciudadYEstado">Cuidad y estado</div> 
                            <div id="codigoPostal" name="nombrePersona">Codigo Postal</div> 
                        </td>
                        <td><a href="registroDomicilio.html">Cambiar</a></td>
                    </tr>
                    <tr>
                        <th scope="row"><h2>2</h2></th>
                        <td colspan="-1"><h2>Método de Pago</h2></td>
                        <td><div id="nombreTarjeta" name="nombreTarjeta">Nombre de la Tarjeta y la terminacion (####)</div></td>
                        <td><a href="registroTarjetas.html">Cambiar</a></td>
                    </tr>
                    <tr>
                        <th scope="row"><h2>3</h2></th>
                        <td colspan="4"><h2>Revisar artículos y envíos</h2></td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <div class="container-fluid">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row" id="contenedorProductos" name="contenedorProductos">

                                            <div class="col">
                                                <div class="card" style="width: 18rem;">
                                                    <div class="p-3">
                                                        <img src="../../dm 150.jpg" class="card-img-top" alt="Aqui va la imagen del producto">
                                                        <h5 class="card-title text-center">Producto</h5>
                                                        <p class="card-text">Descripción del producto</p>
                                                        <div class="row">
                                                            <div class="col">
                                                                <button class="btn btn-danger">Quitar</button>
                                                            </div>
                                                            <div class="col">
                                                                <h6 class="h6">Cantidad:</h6>
                                                            </div>
                                                            <div class="col">
                                                                <select class="form-select">
                                                                    <option value="1">1</option>
                                                                    <option value="2">2</option>
                                                                    <option value="3">3</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </table>
                <br>
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <div class="d-grid gap-2">
                                        <a href="#" class="btn btn-warning text-center">Realizar pedido y pagar</a>
                                    </div>
                                </div>
                                <div  class="col-8 text-center">
                                    <strong id="subtotal" name="subtotal">Subtotal: ("CantidadProductos"): CantidadAPagar</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div  class="col">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <a href="#" class="btn btn-warning text-center">Realizar pedido y pagar</a>
                        </div>
                        <p class="card-text text-center">Al realizar tu pedido aceptas los <a href="#">terminos y condiciones</a></p>
                        <hr>
                        <div class="text-center">
                            <strong>Confirmación del Pedido</strong><br>
                        </div>
                        <div>
                            <div class="row">
                                <div class="col">Productos:</div>
                                <div class="col" style="text-align: right;" id="totalProductos" name="totalProductos">Holaa</div>
                            </div>
                            <div class="row">
                                <div class="col">Envio:</div>
                                <div class="col" style="text-align: right;" id="totalEnvio" name="totalEnvio">Grapa</div>
                            </div>
                            <div class="row">
                                <div class="col">Promociones:</div>
                                <div class="col" style="text-align: right;" id="totalPromociones" name="totalPromociones">Ninguna</div>
                            </div>
                        </div>
                        <hr>
                        <strong id="subtotal2" name="subtotal2">Subtotal: ("CantidadProductos"): CantidadAPagar</strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<script src="{{ mix('js/app.js') }}" type="text/javascript"></script>
</html>