<!DOCTYPE html>
<html>
  <head>
    <title>Inicio de sesión</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
      body {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
      }
      .container-login {
        max-width: 400px;
        margin: 0 auto;
        margin-top: 100px;
      }
      .btn-register {
        background-color: #007bff;
        border-color: #007bff;
      }
    </style>
  </head>
  <body>
    <header class="bg-dark text-white py-2">
      <div class="container">
        <h1 class="mb-0">Zapateria</h1>
      </div>
    </header>
    <div class="container flex-grow-1">
      <div class="container-login bg-light p-5 rounded">
        <h1 class="text-center mb-4">Iniciar sesión</h1>
        <form>
          <div class="form-group">
            <label for="email">Correo electrónico:</label>
            <input type="email" class="form-control" id="email" required>
          </div>
          <div class="form-group">
            <label for="password">Contraseña:</label>
            <input type="password" class="form-control" id="password" required>
          </div>
          <button type="submit" class="btn btn-primary btn-block" onclick="principal()">Iniciar sesión</button>
        </form>
        <hr>
        <p class="text-center">¿No tienes una cuenta? <a href="#" class="btn-register text-white">Regístrate aquí</a></p>
      </div>
    </div>
  </body>
  <script src="../../js/LogIn.js"></script>
</html>
